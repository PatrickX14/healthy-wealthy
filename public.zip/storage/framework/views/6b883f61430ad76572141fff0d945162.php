<?php $__env->startSection('content'); ?>
    <div class="container mt-5 bg-body-secondary pb-3 rounded-4">
        <form method="POST" action="<?php echo e(route('food.upload')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row align-items-start g-3 fs-4">
                <div class="col-sm-12">
                    <label class="h-100 w-100" for="">ชื่ออาหาร</label>
                    <input class="h-100 w-100 form-control" type="text" name="foodname">
                    <?php $__errorArgs = ['foodname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-sm-4">
                    <label class="h-100 w-100" for="">ปริมาณแคลอรี่</label>
                    <input class="h-100 w-100 form-control" type="number" name="foodkcal">
                    <?php $__errorArgs = ['foodkcal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-4">
                    <label class="h-100 w-100" for="">ประเภทอาหาร</label>
                    <select class="form-select" aria-label="Default select example" name="foodcategory">
                        <option selected disabled>เลือกประเภทอาหาร</option>
                        <option value="ของทอด">ของทอด</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                    </select>
                    <?php $__errorArgs = ['foodcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-4">
                    <label class="h-100 w-100" for="">โรค</label>
                    <select class="form-select" aria-label="Default select example" name="foodcategory">
                        <option selected disabled>เลือกโรค</option>
                        <option value="ของทอด">ของทอด</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                    </select>
                    <?php $__errorArgs = ['foodcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12">
                    <label for="formFile" class="form-label">รูปภาพอาหาร</label>
                    <input class="form-control" type="file" name="picture">
                    <?php $__errorArgs = ['picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-6">
                    <label class="h-100 w-100" for="">แหล่งอ้างอิง</label>
                    <input class="h-100 w-100 form-control" type="text" name="refer">
                    <?php $__errorArgs = ['refer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-6">
                    <label class="h-100 w-100" for="">Embed จาก Youtube</label>
                    <input class="h-100 w-100 form-control" type="text" name="video">
                    <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-6">
                    <label class="h-100 w-100" for="">ขั้นตอนการปรุงอาหาร</label>
                    <textarea class="w-100 form-control" style="height: 200px; overflow:visible;" type="number" name="foodrecipe"></textarea>
                    <?php $__errorArgs = ['foodrecipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-6">
                    <label class="h-100 w-100" for="">วัตถุดิบ</label>
                    <textarea class="w-100 form-control" style="height: 200px; overflow:visible;" type="number" name="foodingr"></textarea>
                    <?php $__errorArgs = ['foodingr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger fs-6"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <hr class="my-4">
                <div class="col-12 mt-0">
                    <button type="submit"
                        class="btn form-control bg-success text-light col-12 justify-center w-100">Submit</button>
                </div>
            </div>
        </form>
    </div>
    <script src="<?php echo e(asset('js/foodupload.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\healthy-wealthy\resources\views/foodupload.blade.php ENDPATH**/ ?>