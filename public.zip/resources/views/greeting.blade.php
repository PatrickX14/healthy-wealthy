<div>
    @foreach ($name as $name)
        <p>{{$name}}</p>
    @endforeach
</div>
