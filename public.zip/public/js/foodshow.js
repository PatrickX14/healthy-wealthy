const edibleFood = document.getElementById("edible");
const avoidFood = document.getElementById("shouldAvoid");

avoidFood.addEventListener("click", ()=>{
    
});
